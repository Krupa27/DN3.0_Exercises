package com.example.EmployeeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.EmployeeManagementSystem.entity.Department;
import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class EmployeeManagementSystemApplication implements CommandLineRunner {
	
	@Autowired
    private EmployeeService employeeService;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemApplication.class, args);
	}
	
	@Override
    public void run(String... args) throws Exception {
        // Create departments
        Department department1 = new Department("HR");
        Department department2 = new Department("IT");

        employeeService.saveDepartment(department1);
        employeeService.saveDepartment(department2);

        // Create employees
        Employee e1 = new Employee("Krupa sagar", "sagar@example.com", department1);
        Employee e2 = new Employee("John Vincent", "vincent@example.com", department2);

        employeeService.saveEmployee(e1);
        employeeService.saveEmployee(e2);

        // Fetch all employees
        List<Employee> employees = employeeService.getAllEmployees();
        System.out.println("All Employees: " + employees);

        // Fetch employee by ID
        Employee employee = employeeService.getEmployeeById(e1.getId()).orElse(null);
        System.out.println("Employee with ID " + e1.getId() + ": " + employee);

        // Fetch employees by name
        List<Employee> employeesByName = employeeService.getEmployeeByName("Krupa sagar");
        System.out.println("Employees with name 'Krupa sagar': " + employeesByName);

        // Fetch employees by department
        List<Employee> employeesInIT = employeeService.getEmployeesByDepartmentId(department2.getId());
        System.out.println("Employees in IT department: " + employeesInIT);

        // Fetch employee by email
        Employee employeeByEmail = employeeService.getEmployeeByEmail("vincent@example.com");
        System.out.println("Employee with email 'vincent@example.com': " + employeeByEmail);

        // Fetch employees with names containing "John"
        List<Employee> employeesWithNameContaining = employeeService.getEmployeesByNameContaining("John");
        System.out.println("Employees with names containing 'John': " + employeesWithNameContaining);

        // Delete an employee by ID
        employeeService.deleteEmployee(e2.getId());
        System.out.println("Employee with ID " + e2.getId() + " has been deleted.");

        // Fetch all employees after deletion
        employees = employeeService.getAllEmployees();
        System.out.println("All Employees after deletion: " + employees);
    }

}



