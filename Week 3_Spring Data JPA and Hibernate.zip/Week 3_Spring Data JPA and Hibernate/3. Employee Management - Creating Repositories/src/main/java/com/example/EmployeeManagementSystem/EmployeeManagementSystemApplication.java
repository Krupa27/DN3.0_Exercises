package com.example.EmployeeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.EmployeeManagementSystem.entity.Department;
import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class EmployeeManagementSystemApplication implements CommandLineRunner {
	
	@Autowired
    private EmployeeService employeeService;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemApplication.class, args);
	}
	
	@Override
    public void run(String... args) throws Exception {
        Department d1 = new Department("HR");
        Department d2 = new Department("IT");

        employeeService.saveDepartment(d1);
        employeeService.saveDepartment(d2);

        Employee e1 = new Employee("Krupa", "sagar@example.com", d1);
        Employee e2 = new Employee("sagar", "sagar@example.com", d2);

        employeeService.saveEmployee(e1);
        employeeService.saveEmployee(e2);

        List<Employee> employees = employeeService.getAllEmployees();
        System.out.println("All Employees: " + employees);

        Employee employee = employeeService.getEmployeeById(e1.getId()).orElse(null);
        System.out.println("Employee with ID " + e1.getId() + ": " + employee);

        List<Employee> employeesByName = employeeService.getEmployeeByName("John Doe");
        System.out.println("Employees with name 'Krupa sagar': " + employeesByName);

        List<Employee> employeesInIT = employeeService.getEmployeesByDepartmentId(d2.getId());
        System.out.println("Employees in IT department: " + employeesInIT);

        Employee employeeByEmail = employeeService.getEmployeeByEmail("jane.smith@example.com");
        System.out.println("Employee with email 'jane.smith@example.com': " + employeeByEmail);

        List<Employee> employeesWithNameContaining = employeeService.getEmployeesByNameContaining("Jane");
        System.out.println("Employees with names containing 'Jane': " + employeesWithNameContaining);

        employeeService.deleteEmployee(e2.getId());
        System.out.println("Employee with ID " + e2.getId() + " has been deleted.");

        employees = employeeService.getAllEmployees();
        System.out.println("All Employees after deletion: " + employees);
    }
	
}



