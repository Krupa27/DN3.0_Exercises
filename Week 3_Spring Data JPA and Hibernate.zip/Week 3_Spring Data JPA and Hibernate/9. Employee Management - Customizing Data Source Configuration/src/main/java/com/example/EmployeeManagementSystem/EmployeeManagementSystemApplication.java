package com.example.EmployeeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.EmployeeManagementSystem.entity.Department;
import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import com.example.EmployeeManagementSystem.projection.EmployeeProjection;
import com.example.EmployeeManagementSystem.dto.EmployeeDTO;
import com.example.EmployeeManagementSystem.repository.primary.EmployeePrimaryRepository;
import com.example.EmployeeManagementSystem.repository.secondary.DepartmentSecondaryRepository;


import java.util.List;

@SpringBootApplication
@EnableJpaAuditing
public class EmployeeManagementSystemApplication implements CommandLineRunner {

	@Autowired
    private EmployeeService es;
	
	@Autowired
	private EmployeePrimaryRepository employeePrimaryRepository;

	@Autowired
	private DepartmentSecondaryRepository departmentSecondaryRepository;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemApplication.class, args);
	}
	
	@Override
    public void run(String... args) throws Exception {
		
		
        Department d1 = new Department("HR");
        Department d2 = new Department("IT");
        Department d3 = new Department("Product");

        es.saveDepartment(d1);
        es.saveDepartment(d2);

        // Create employees
        Employee e1 = new Employee("John Doe", "john.doe@example.com", d1);
        Employee e2 = new Employee("Jane Smith", "jane.smith@example.com", d2);
        Employee employee4 = new Employee("Krupa sagar", "ksmalloju@gmail.com", d3);
        

        es.saveEmployee(e1);
        es.saveEmployee(e2);

        // Fetch all employees
        List<Employee> employees = es.getAllEmployees();
        System.out.println("All Employees: " + employees);

        // Fetch employee by ID
        Employee employee = es.getEmployeeById(e1.getId()).orElse(null);
        System.out.println("Employee with ID " + e1.getId() + ": " + employee);
        


        // Fetch employees by name
        List<Employee> employeesByName = es.getEmployeeByName("Krupa sagar");
        System.out.println("Employees with name 'John Doe': " + employeesByName);
        //auditing methods for exercise 7
        System.out.println("------Output for Exercise 7: Auditing-----------");
        System.out.println("Created Date: " + employee.getCreatedDate());
        System.out.println("Last Modified Date: " + employee.getLastModifiedDate());

        // Fetch employees by department
        List<Employee> employeesInIT = es.getEmployeesByDepartmentId(d2.getId());
        System.out.println("Employees in IT department: " + employeesInIT);

        // Fetch employee by email
        Employee employeeByEmail = es.getEmployeeByEmail("jane.smith@example.com");
        System.out.println("Employee with email 'jane.smith@example.com': " + employeeByEmail);

        // Fetch employees with names containing "Jane"
        List<Employee> employeesWithNameContaining = es.getEmployeesByNameContaining("Jane");
        System.out.println("Employees with names containing 'Jane': " + employeesWithNameContaining);

        // Delete an employee by ID
        es.deleteEmployee(e2.getId());
        System.out.println("Employee with ID " + e2.getId() + " has been deleted.");

        // Fetch all employees after deletion
        employees = es.getAllEmployees();
        System.out.println("All Employees after deletion: " + employees);
        
        
        //Testing custom queries
        System.out.println("----- Testing Custom Queries -----");
        
        // Find employees by department name
        List<Employee> employeesInHR = es.findEmployeesByDepartmentName("HR");
        System.out.println("Employees in HR department: " + employeesInHR);

        // Find employee by email
        Employee employeeWithEmail = es.findEmployeeByEmail("john.doe@example.com");
        System.out.println("Employee with email 'john.doe@example.com': " + employeeWithEmail);

        // Find employees by name containing (case-insensitive)
        List<Employee> employeesWithDoe = es.findEmployeesByNameContainingIgnoreCase("Doe");
        System.out.println("Employees with names containing 'Doe': " + employeesWithDoe);
        
        
        System.out.println("-------Testing Projections---------");
        
        List<EmployeeProjection> employeeProjections = es.getAllEmployeeProjections();
	    employeeProjections.forEach(ep -> System.out.println("Name: " + ep.getName() + ", Email: " + ep.getEmail()));

	    // Test class-based projection
	    List<EmployeeDTO> employeeDTOs = es.getEmployeeDTOs();
	    employeeDTOs.forEach(dto -> System.out.println(dto));
	    
	    
	    
	    
	    //// Interact with the primary data source
	    System.out.println("Exercise-9 implementation");
	    System.out.println("---------Customizing Data Source Configuration---------------");
	    Department department9 = new Department("SDE-9");
	    
        Employee employee9 = new Employee("Khushi", "happiness@example.com", department9);
        employeePrimaryRepository.save(employee9);

        // Interact with the secondary data source
        Department department = new Department("HR");
        departmentSecondaryRepository.save(department);

        // Verify data in both data sources
        System.out.println("Employees: " + employeePrimaryRepository.findAll());
        System.out.println("Departments: " + departmentSecondaryRepository.findAll());
        
       
    }
	
	//output for the above code:
	//All Employees: [com.example.EmployeeManagementSystem.entity.Employee@6edb093f, com.example.EmployeeManagementSystem.entity.Employee@6805415d]
	//Employee with ID 1: com.example.EmployeeManagementSystem.entity.Employee@1a916120
	//Employees with name 'John Doe': [com.example.EmployeeManagementSystem.entity.Employee@6d3194ff]
	//Employees in IT department: [com.example.EmployeeManagementSystem.entity.Employee@701c413]
	//Employee with email 'jane.smith@example.com': com.example.EmployeeManagementSystem.entity.Employee@7cb4d4ee
	//Employees with names containing 'Jane': [com.example.EmployeeManagementSystem.entity.Employee@7894a250]
	//Employee with ID 2 has been deleted.
	//All Employees after deletion: [com.example.EmployeeManagementSystem.entity.Employee@140fa482]

}



