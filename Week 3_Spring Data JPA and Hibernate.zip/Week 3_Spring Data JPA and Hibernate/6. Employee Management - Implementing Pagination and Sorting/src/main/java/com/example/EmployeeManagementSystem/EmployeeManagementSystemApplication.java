package com.example.EmployeeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.EmployeeManagementSystem.entity.Department;
import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import java.util.List;

@SpringBootApplication
public class EmployeeManagementSystemApplication implements CommandLineRunner {
	
	@Autowired
    private EmployeeService es;
	

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemApplication.class, args);
	}
	
	@Override
    public void run(String... args) throws Exception {
        // Create departments
        Department d1 = new Department("HR");
        Department d2 = new Department("IT");

        es.saveDepartment(d1);
        es.saveDepartment(d2);

        // Create employees
        Employee e1 = new Employee("John Doe", "john.doe@example.com", d1);
        Employee e2 = new Employee("Jane Smith", "jane.smith@example.com", d2);

        es.saveEmployee(e1);
        es.saveEmployee(e2);

        // Fetch all employees
        List<Employee> employees = es.getAllEmployees();
        System.out.println("All Employees: " + employees);

        // Fetch employee by ID
        Employee employee = es.getEmployeeById(e1.getId()).orElse(null);
        System.out.println("Employee with ID " + e1.getId() + ": " + employee);

        // Fetch employees by name
        List<Employee> employeesByName = es.getEmployeeByName("John Doe");
        System.out.println("Employees with name 'John Doe': " + employeesByName);

        // Fetch employees by department
        List<Employee> employeesInIT = es.getEmployeesByDepartmentId(d2.getId());
        System.out.println("Employees in IT department: " + employeesInIT);

        // Fetch employee by email
        Employee employeeByEmail = es.getEmployeeByEmail("jane.smith@example.com");
        System.out.println("Employee with email 'jane.smith@example.com': " + employeeByEmail);

        // Fetch employees with names containing "Jane"
        List<Employee> employeesWithNameContaining = es.getEmployeesByNameContaining("Jane");
        System.out.println("Employees with names containing 'Jane': " + employeesWithNameContaining);

        // Delete an employee by ID
        es.deleteEmployee(e2.getId());
        System.out.println("Employee with ID " + e2.getId() + " has been deleted.");

        // Fetch all employees after deletion
        employees = es.getAllEmployees();
        System.out.println("All Employees after deletion: " + employees);
        
        
        //Testing custom queries
        System.out.println("----- Testing Custom Queries -----");
        
        // Find employees by department name
        List<Employee> employeesInHR = es.findEmployeesByDepartmentName("HR");
        System.out.println("Employees in HR department: " + employeesInHR);

        // Find employee by email
        Employee employeeWithEmail = es.findEmployeeByEmail("john.doe@example.com");
        System.out.println("Employee with email 'john.doe@example.com': " + employeeWithEmail);

        // Find employees by name containing (case-insensitive)
        List<Employee> employeesWithDoe = es.findEmployeesByNameContainingIgnoreCase("Doe");
        System.out.println("Employees with names containing 'Doe': " + employeesWithDoe);
        
       
    }
	
}



