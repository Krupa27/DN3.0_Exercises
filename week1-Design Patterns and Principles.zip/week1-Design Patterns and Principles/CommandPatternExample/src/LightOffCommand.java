public class LightOffCommand implements Command {
    private Light y;

    public LightOffCommand(Light y) {
        this.y = y;
    }
    public void execute() {
        y.turnOff();
    }
}