public class CreditCardPayment implements PaymentStrategy {
    private String CardNum;
    private String holderName;

    public CreditCardPayment(String CardNum, String holderName) {
        this.CardNum = CardNum;
        this.holderName = holderName;
    }
    public void pay(double Amt) {
        System.out.println("Paid " + Amt + " using Credit Card: " + CardNum +" ,Card-Holder Name: "+holderName);
    }
}
