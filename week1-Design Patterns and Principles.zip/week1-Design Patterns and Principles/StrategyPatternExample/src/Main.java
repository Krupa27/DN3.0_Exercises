// Main.java
public class Main {
    public static void main(String[] args) {
        PaymentContext payContxt = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "Meenakshi Sachin Tendulkar");
        payContxt.setPaymentStrategy(creditCardPayment);
        payContxt.pay(1650.75);

        PaymentStrategy paypalpaymnt = new PayPalPayment("sachin@gmail.com");
        payContxt.setPaymentStrategy(paypalpaymnt);
        payContxt.pay(1050.20);
    }
}

