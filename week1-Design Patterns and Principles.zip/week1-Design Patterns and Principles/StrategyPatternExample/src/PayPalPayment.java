public class PayPalPayment implements PaymentStrategy {
    private String Email;

    public PayPalPayment(String Email) {
        this.Email = Email;
    }
    public void pay(double amount) {
        System.out.println("Paid " + amount + " Via PayPal Acc.: " + Email);
    }
}