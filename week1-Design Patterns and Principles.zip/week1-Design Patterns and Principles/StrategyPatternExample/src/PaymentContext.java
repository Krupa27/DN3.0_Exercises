public class PaymentContext {
    private PaymentStrategy payStrategy;

    public void setPaymentStrategy(PaymentStrategy payStrategy) {
        this.payStrategy = payStrategy;
    }

    public void pay(double amount) {
        if (payStrategy == null) {
            System.out.println("Payment method is not selected.");
        } else {
            payStrategy.pay(amount);
        }
    }
}
