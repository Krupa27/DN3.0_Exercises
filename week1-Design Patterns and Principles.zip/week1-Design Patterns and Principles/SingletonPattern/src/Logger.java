public class Logger {

    static Logger Inst;


    public Logger() {

    }

    public static Logger getInstance() {
        if (Inst == null) {
            synchronized (Logger.class) {
                if (Inst == null) {
                    Inst = new Logger();
                }
            }
        }
        return Inst;
    }

    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}


