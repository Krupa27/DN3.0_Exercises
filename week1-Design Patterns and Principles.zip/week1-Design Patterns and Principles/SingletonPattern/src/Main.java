public class Main {

    public static void main(String[] args) {

        Logger log1 = Logger.getInstance();
        Logger log2 = Logger.getInstance();

        log1.log("This is First log message.");
        log2.log("This is Second log message.");

        if (log1 == log2) {
            System.out.println("Both log1 & log2 are the same Inst.");
        } else {
            System.out.println("log1 and & are different Inst.");
        }
    }
}
