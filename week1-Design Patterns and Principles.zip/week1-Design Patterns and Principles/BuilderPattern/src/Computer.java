
public class Computer {
    
    String cpu;
    String ram;

    String storage;
    String graphix;
    String supply;
    String coolingSystem;

    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.graphix = builder.graphix;
        this.supply = builder.supply;
        this.coolingSystem = builder.coolingSystem;
    }

    public String getCPU() {
        return cpu;
    }

    public String getRAM() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public String getGraphicsCard() {
        return graphix;
    }

    public String getPowerSupply() {
        return supply;
    }

    public String getCoolingSystem() {
        return coolingSystem;
    }

    public String toString() {
        return "Computer [cpu=" + cpu + ", ram=" + ram + ", storage=" + storage + 
               ", graphix=" + graphix + ", supply=" + supply + 
               ", coolingSystem=" + coolingSystem + "]";
    }

    public static class Builder {
        
        private final String cpu;
        private final String ram;

        String storage;
        String graphix;
        String supply;
        String coolingSystem;

        public Builder(String cpu, String ram) {
            this.cpu = cpu;
            this.ram = ram;
        }

        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGraphicsCard(String graphix) {
            this.graphix = graphix;
            return this;
        }

        public Builder setPowerSupply(String supply) {
            this.supply = supply;
            return this;
        }

        public Builder setCoolingSystem(String coolingSystem) {
            this.coolingSystem = coolingSystem;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
