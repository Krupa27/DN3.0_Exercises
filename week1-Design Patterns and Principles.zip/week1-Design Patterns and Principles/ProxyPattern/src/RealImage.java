
public class RealImage implements Image {
    private String FileName;

    public RealImage(String FileName) {
        this.FileName = FileName;
        loadImageFromDisk();
    }

    private void loadImageFromDisk() {
        System.out.println("Loading " + FileName + " from remote server...");
    }

    public void display() {
        System.out.println("Displaying " + FileName);
    }
}
