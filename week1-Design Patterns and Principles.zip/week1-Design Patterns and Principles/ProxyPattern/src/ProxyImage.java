
public class ProxyImage implements Image {
    private RealImage realimg;
    private String fileName;

    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }

    public void display() {
        if (realimg == null) {
            realimg = new RealImage(fileName);
        }
        realimg.display();
    }
}
