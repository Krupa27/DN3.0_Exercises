public class MainCl{
    public static void main(String[] args) {
        
        PayPalGateway paypalGatwy = new PayPalGateway();
        PaymentProcessor payPalProcessor = new PayPalAdapter(paypalGatwy);
        payPalProcessor.processPayment(1024.70);

        StripeGateway stripeGatwy = new StripeGateway();
        PaymentProcessor stripeProcessor = new StripeAdapter(stripeGatwy);
        stripeProcessor.processPayment(2010.50);
    }
}
