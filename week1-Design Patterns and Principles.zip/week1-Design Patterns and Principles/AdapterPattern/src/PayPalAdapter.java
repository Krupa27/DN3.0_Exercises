public class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway paypalgatwy;

    public PayPalAdapter(PayPalGateway paypalgatwy) {
        this.paypalgatwy = paypalgatwy;
    }

    public void processPayment(double amount) {
        paypalgatwy.makePayment(amount);
    }
}