public class CustomerService {
    private final CustomerRepository userRepo;

    public CustomerService(CustomerRepository userRepo) {
        this.userRepo = userRepo;
    }

    public Customer getCustomerById(int id) {
        return userRepo.findCustomerById(id);
    }
}
