public class Customer {
    private int id;
    private String Name;

    public Customer(int id, String Name) {
        this.id = id;
        this.Name = Name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return Name;
    }
}
