public class WordDocument implements Document{
    
    public void open() {
        System.out.println("Opening MS Word doc.");
    }

    public void close() {
        System.out.println("Closing MS Word doc.");
    }

    public void save() {
        System.out.println("Saving MS Word doc.");
    }
}
