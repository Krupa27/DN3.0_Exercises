public class ExcelDocument implements Document{
    
    public void open() {
        System.out.println("Opening MS Excel doc.");
    }

    public void close() {
        System.out.println("Closing MS Excel doc.");
    }

    public void save() {
        System.out.println("Saving MS Excel doc.");
    }
}
