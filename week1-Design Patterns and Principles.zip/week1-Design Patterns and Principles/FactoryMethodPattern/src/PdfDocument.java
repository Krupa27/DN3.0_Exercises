public class PdfDocument implements Document{
    
    public void open() {
        System.out.println("Opening PDF doc.");
    }

    public void close() {
        System.out.println("Closing PDF doc.");
    }

    public void save() {
        System.out.println("Saving PDF doc.");
    }
}
