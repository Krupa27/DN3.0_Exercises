public class Student {
    private String Name;
    private String id;
    private String GradeFact;
    public Student(String Name, String id, String GradeFact) {
        this.Name = Name;
        this.id = id;
        this.GradeFact = GradeFact;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGrade() {
        return GradeFact;
    }

    public void setGrade(String GradeFact) {
        this.GradeFact = GradeFact;
    }
}

