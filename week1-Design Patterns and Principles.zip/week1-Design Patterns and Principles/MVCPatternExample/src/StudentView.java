public class StudentView {
    public void displayStudentDetails(String studentName, String studId, String stuGrade) {
        System.out.println("Student Details:");
        System.out.println("Name: " + studentName);
        System.out.println("ID: " + studId);
        System.out.println("Grade: " + stuGrade);
    }
}
