public class StudentController {
    Student model;
    StudentView v;

    public StudentController(Student model, StudentView v) {
        this.model = model;
        this.v = v;
    }

    public void setStudentName(String name) {
        model.setName(name);
    }

    public String getStudentName() {
        return model.getName();
    }

    public void setStudentId(String id) {
        model.setId(id);
    }

    public String getStudentId() {
        return model.getId();
    }

    public void setStudentGrade(String grade) {
        model.setGrade(grade);
    }

    public String getStudentGrade() {
        return model.getGrade();
    }

    public void updateView() {
        v.displayStudentDetails(model.getName(), model.getId(), model.getGrade());
    }
}
