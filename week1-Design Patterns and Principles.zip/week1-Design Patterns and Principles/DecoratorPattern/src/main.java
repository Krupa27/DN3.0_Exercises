public class main {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Forwarding notifications via Email:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nForwarding notifications via Email and SMS:");
        smsAndEmailNotifier.send("Hello via Email and SMS!");

        System.out.println("\nForwarding notifications via Email, SMS, Insta:");
        slackSmsAndEmailNotifier.send("Hello via Email, SMS, Insta!");
    }
}
