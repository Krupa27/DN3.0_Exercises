public class WebApp implements Observer {
    public void update(String stokName, double stokPrice) {
        System.out.println("Web App: Stock " + stokName + " is now $" + stokPrice);
    }
}