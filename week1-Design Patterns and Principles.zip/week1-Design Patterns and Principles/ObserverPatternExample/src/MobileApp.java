public class MobileApp implements Observer {
    public void update(String stokName, double stokPrice) {
        System.out.println("Mobile App: Stock " + stokName + " is now $" + stokPrice);
    }
}