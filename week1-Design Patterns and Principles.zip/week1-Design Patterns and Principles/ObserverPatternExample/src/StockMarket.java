import java.util.*;

public class StockMarket implements Stock {
    List<Observer> observers;
    String stokName;
    double stokPrice;

    public StockMarket(String stokName, double stokPrice) {
        observers = new ArrayList<>();
        this.stokName = stokName;
        this.stokPrice = stokPrice;
    }

    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stokName, stokPrice);
        }
    }

    public void setStockPrice(double stokPrice) {
        this.stokPrice = stokPrice;
        notifyObservers();
    }
}