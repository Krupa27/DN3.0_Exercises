public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("TechCorp", 100.00);
        Observer mob = new MobileApp();
        Observer web = new WebApp();

        stockMarket.registerObserver(mob);
        stockMarket.registerObserver(web);

        System.out.println("Updating and Fetching S.P...");
        stockMarket.setStockPrice(1065.65);

        System.out.println("Updating and Fetching S.P again...");
        stockMarket.setStockPrice(155.40);

        stockMarket.deregisterObserver(mob);
        System.out.println("Updating S.P After, deregistering mobile app...");
        stockMarket.setStockPrice(143.35);
    }
}
